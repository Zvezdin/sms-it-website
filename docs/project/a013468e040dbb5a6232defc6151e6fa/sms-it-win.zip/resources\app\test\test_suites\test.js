const assert = require('assert');
const CONFIG = require('../config');


describe('Testing SMS chatbot', function () {
    this.timeout(5000)

    // Tests
    it('Go to "Phone Simulator" page', async function () {
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const testButton = await E2EBotRow.$('[id="test"]')
        testButton.click()

        return (await app.client.waitUntilTextExists('h2', 'Phone Simulator: ' + CONFIG.E2E_botName))
    })

    it('User can send message', async function () {
        const userMessage = 'Hello'
        await app.client.$('<textarea />').then(inp => inp.setValue(userMessage))
        await app.client.$('button=Send').then(btn => btn.click())

        return (app.client.waitUntilTextExists('.userMsg', userMessage))
    })

    it('Bot can send reply', async function () {
        this.slow(400)
        return (app.client.$('.botMsg'))
    })

    it('Back button returns to "Manage Chatbots" page', async function () {
        await app.client.$('[alt="Back"]').then(btn => btn.click())

        return (app.client.waitUntilTextExists('h2', 'Manage Chatbots'))
    })
    
})
