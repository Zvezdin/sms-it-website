const assert = require('assert');
const CONFIG = require('../config');


describe('Deleting an undeployed chatbot', function () {
    this.timeout(20000)

    // Tests
    it('Confirmation prompt for deleting bot', async function () {
        this.slow(3000)
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
        const deleteButton = await E2EBotRow.$('[id="delete"]')
        deleteButton.click()

        return (await app.client.$('div=DELETING BOT'))
    })

    it('Clicking "Cancel" closes prompt and does nothing', async function () {
        this.slow(750)
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
        await app.client.pause(500)
        await app.client.$('button=CANCEL').then(btn => btn.click())

        return (await E2EBotRow.isDisplayed())
    })

    it('Clicking "Yes" deletes bot', async function () {
        this.slow(12000)
        this.timeout(16000)

        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
        const deleteButton = await E2EBotRow.$('[id="delete"]')
        await deleteButton.click()
        await app.client.pause(500)
        await app.client.$('button=YES').then(btn => btn.click())

        const deletedNotif = await app.client.$('.notification=' + CONFIG.E2E_botName + '2 was deleted')
        return deletedNotif.waitForDisplayed({ timeout: 16000 })
    })

    it('Delete second chatbot', async function () {
        this.slow(20000)
        this.timeout(16000)

        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const deleteButton = await E2EBotRow.$('[id="delete"]')
        await deleteButton.click()
        await app.client.pause(500)
        await app.client.$('button=YES').then(btn => btn.click())

        const deletedNotif = await app.client.$('.notification=' + CONFIG.E2E_botName + ' was deleted')
        return deletedNotif.waitForDisplayed({ timeout: 16000 })
    })
    
})
