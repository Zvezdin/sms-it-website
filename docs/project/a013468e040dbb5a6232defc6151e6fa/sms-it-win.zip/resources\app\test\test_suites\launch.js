const assert = require('assert');
const CONFIG = require('../config');


describe('Application launch', function () {
    this.timeout(10000)

    // Tests
    it('Shows an initial window', async function () {
        return app.client.getWindowCount().then(function (count) {
            assert.strictEqual(count, 1)
        })
    })

    it('Login page is shown on startup', async function () {
        return (await app.client.$('h2')).getText()
            .then(text => assert.strictEqual(text, 'Login via Twilio'))
    })

    it('Invalid credentials', async function () {
        this.slow(1500)
        await app.client.$('button').then(login => login.click())
        return app.client.waitUntilTextExists('.notification', 'Error!\nInvalid credentials!')
    })

    it('Log in to "Manage Chatbots" screen', async function () {
        this.slow(2500)
        const inputAccountSID = await app.client.$('[name="twilioAccountSid"]').then(elem => elem.elementId)
        const inputAuthToken = await app.client.$('[name="twilioAuthToken"]').then(elem => elem.elementId)
        const loginButton = await app.client.$('button')

        app.client.elementSendKeys(inputAccountSID, CONFIG.creds_accountSID)
        app.client.elementSendKeys(inputAuthToken, CONFIG.creds_authToken)
        loginButton.click()

        return (await app.client.waitUntilTextExists('h2', 'Manage Chatbots'))
    })

    it('Log out to "Login" page', async function () {
        await app.client.$('[alt="Log Out"]').then(btn => btn.click())

        return (await app.client.waitUntilTextExists('h2', 'Login via Twilio'))
    })
    
})
