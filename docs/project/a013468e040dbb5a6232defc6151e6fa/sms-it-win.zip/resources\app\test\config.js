const path = require('path');

/**
 * Account SID to use when running the tests - this uses an environment variable called `TWILIO_ACCOUNT_SID`.
 * For instructions on how to set an environment variable, see this [article](https://www.twilio.com/blog/2017/01/how-to-set-environment-variables.html).
 */
exports.creds_accountSID = process.env.TWILIO_ACCOUNT_SID;
/**
 * Account Auth Token to use when running the tests - this uses an environment variable called `TWILIO_AUTH_TOKEN`.
 * For instructions on how to set an environment variable, see this [article](https://www.twilio.com/blog/2017/01/how-to-set-environment-variables.html).
 */
exports.creds_authToken = process.env.TWILIO_AUTH_TOKEN;

/**
 * In test/config.js, set this to the name of any existing bot connected to your Twilio account.
 */
exports.botNameThatIsNotUnique = 'MSK-LIVE';

/**
 * In test/config.js, set this to the number of (undeployed and deployed) chatbots tied to your Twilio account.
 */
exports.numberOfBotsAlreadyOnAccount = 5;

/**
 * The file path for a valid Voiceflow file. Change this in test/config.js.
 * Use `../../../../valid.vf` to point to `valid.vf` on the same level as the root directory of this COMP0016_2020_21_Team28 repo:

 * ```
 * ├── COMP0016_2020_21_Team28/
 * |    └── etc.
 * ├── valid.vf
 * └── unsupported.vf
 * ```
 */
exports.vf_filePath = path.join(__dirname, '..', '..', '..', '..', 'valid.vf');

/**
 * The file path for an unsupported Voiceflow file. Change this in test/config.js.
 * Use `../../../../unsupported.vf` to point to `unsupported.vf` on the same level as the root directory of this COMP0016_2020_21_Team28 repo:
 *
 * ```
 * ├── COMP0016_2020_21_Team28/
 * |    └── etc.
 * ├── valid.vf
 * └── unsupported.vf
 * ```
 */
exports.unsupported_filePath = path.join(__dirname, '..', '..', '..', '..', 'unsupported.vf');

/**
 * The chatbot name to use for the E2E tests - change this is test/config.js and ensure it is unique.
 */
exports.E2E_botName = 'E2Etest';