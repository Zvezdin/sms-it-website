const Application = require('spectron').Application;
const electronPath = require('electron');
const path = require('path');

describe('SMS-it', function () {
    this.timeout(10000)

    // Setup - app is global to be accessed by all tests
    global.app = new Application({
        path: electronPath,
        args: [path.join(__dirname, '..')]
    });

    before(function() {
        return app.start()
    })

    after(function() {
        if (app && app.isRunning()) {
            return app.stop()
        }
    })

    require('./test_suites/launch')
    require('./test_suites/upload')
    require('./test_suites/test')
    require('./test_suites/deploy')
    require('./test_suites/edit')
    require('./test_suites/manage')
    require('./test_suites/unlink')
    require('./test_suites/delete')
})
