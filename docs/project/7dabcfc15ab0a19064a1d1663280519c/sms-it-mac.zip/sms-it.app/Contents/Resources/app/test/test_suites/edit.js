const assert = require('assert');
const CONFIG = require('../config');


describe('Editing a deployed chatbot', function () {
    this.timeout(10000)

    // Tests
    it('Go to "Manage ' + CONFIG.E2E_botName + '" page', async function () {
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const editButton = await E2EBotRow.$('[id="edit"]')
        editButton.click()

        return (await app.client.waitUntilTextExists('h2', 'Manage ' + CONFIG.E2E_botName))
    })

    it('Hovering over in-use phone number shows tooltip', async function () {
        const inUseNumber = await app.client.$('button*=' + CONFIG.botNameThatIsNotUnique)
        await inUseNumber.moveTo()

        return (app.client.waitUntilTextExists('[id="phone_tip"]', 'This number is occupied'))
    })

    it('Select in-use phone number', async function () {
        await app.client.$('button*=' + CONFIG.botNameThatIsNotUnique).then(btn => btn.click())

        return (app.client.waitUntilTextExists('.notification', 'Cannot deploy chatbot to this number!'))
    })

    it('Select available phone number', async function () {
        this.slow(2500)
        const availableNumber = await app.client.$$('button*=Available').then(btns => btns[0])
        await availableNumber.click()

        return (app.client.waitUntilTextExists('.notification', 'Success!'))
    })
    
})
