const assert = require('assert');
const CONFIG = require('../config');


describe('Managing chatbots', function () {
    this.timeout(5000)

    // Tests
    it('Table has headers: name, phone number, date modified, options', async function () {
        const headers = await app.client.$('thead').then(thead => thead.getText())
    
        assert(
            headers.includes('Name') && 
            headers.includes('Phone Number') && 
            headers.includes('Date Modified') && 
            headers.includes('Options')
        )
    })
    
    it('Table displays info on bots', async function () {
        const E2EBotInfo = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..').then(row => row.getText())
        const E2EBotInfo2 = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..').then(row => row.getText())
    
        assert(
            E2EBotInfo.includes(CONFIG.E2E_botName) &&
            E2EBotInfo.length > CONFIG.E2E_botName.length &&
            E2EBotInfo2.includes(CONFIG.E2E_botName + '2') &&
            E2EBotInfo2.length > CONFIG.E2E_botName.length + 1
        )
    })
    
    it('Deployed bots show a phone number', async function () {
        const E2EBotInfo = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..').then(row => row.getText())
        
        assert(
            E2EBotInfo.includes(CONFIG.E2E_botName) &&
            E2EBotInfo.includes('+44')
        )
    })
    
    it('Deployed bots have options: edit, test, delete', async function () {
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
    
        assert(
            await (await E2EBotRow.$('[id="edit"]')).isDisplayed() &&
            await (await E2EBotRow.$('[id="test"]')).isDisplayed() &&
            await (await E2EBotRow.$('[id="unlink"]')).isDisplayed()
        )
    })
    
    it('Undeployed bots do not show a phone number', async function () {
        const E2EBotInfo2 = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..').then(row => row.getText())
        
        assert(
            E2EBotInfo2.includes(CONFIG.E2E_botName + '2') &&
            E2EBotInfo2.includes('UNDEPLOYED')
        )
    })
    
    it('Undeployed bots have options: deploy, test, delete', async function () {
        const E2EBotRow2 = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
    
        assert(
            await (await E2EBotRow2.$('[id="deploy"]')).isDisplayed() &&
            await (await E2EBotRow2.$('[id="test"]')).isDisplayed() &&
            await (await E2EBotRow2.$('[id="delete"]')).isDisplayed()
        )
    })
    
    it('Option buttons have tooltips', async function () {
        var button
        var tooltips = true
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const E2EBotRow2 = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
    
        const buttonIdsDeployed = ['edit', 'test', 'unlink']
        const buttonTipsDeployed = ['Change Number', 'Test SMS Chatbot', 'Unlink from SMS']
        for (var i = 0; i < buttonIdsDeployed.length; i++) {
            var id = buttonIdsDeployed[i]
            var tip = buttonTipsDeployed[i]
    
            button = await E2EBotRow.$('[id="' + id + '"]')
            await button.moveTo()
            tooltips &= await app.client.waitUntilTextExists('[id="' + id + '_tip"]', tip)
        }; 
    
        const buttonIdsUndeployed = ['deploy', 'test', 'delete']
        const buttonTipsUndeployed = ['Deploy to SMS', 'Test SMS Chatbot', 'Delete Chatbot']
        for (var i = 0; i < buttonIdsUndeployed.length; i++) {
            var id = buttonIdsUndeployed[i]
            var tip = buttonTipsUndeployed[i]
    
            button = await E2EBotRow2.$('[id="' + id + '"]')
            await button.moveTo()
            tooltips &= await app.client.waitUntilTextExists('[id="' + id + '_tip"]', tip)
        };
    
        return tooltips
    })
    
    it('Search bar shows total number of bots', async function () {
        const searchBar = await app.client.$('.botSearchInput')
    
        assert.strictEqual((await searchBar.getAttribute('placeholder')), 'Search ' + (CONFIG.numberOfBotsAlreadyOnAccount+2) + ' chatbots')
    })
    
    it('Rows can be filtered with search bar', async function () {
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const E2EBotRow2 = await (await app.client.$('td=' + CONFIG.E2E_botName + '2')).$('..')
    
        const searchBar = await app.client.$('.botSearchInput')
        searchBar.setValue('E2Etest2')
        const filtered = (!(await E2EBotRow.isDisplayed()) && (await E2EBotRow2.isDisplayed()))
        searchBar.setValue('\uE003')
    
        return filtered
    })
    
    it('Clicking "Name" header sorts rows by name', async function () {
        const nameHeader = await app.client.$('th=Name')
        nameHeader.click()
        row1 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[0].getText())
        row2 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[1].getText())
    
        assert(row1.includes('E2Etest') && row2.includes('E2Etest2'))
    
        nameHeader.click()
        nameHeader.click()
    })
    
    it('Clicking "Phone Number" header sorts rows by number', async function () {
        const numberHeader = await app.client.$('th=Phone Number')
        numberHeader.click()
        row1 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[0].getText())
        row2 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[1].getText())
    
        assert(row1.includes('+44') && row2.includes('UNDEPLOYED'))
    
        numberHeader.click()
        numberHeader.click()
    })
    
    it('Clicking "Date Modified" header sorts rows by date', async function () {
        const dateHeader = await app.client.$('th=Name')
        dateHeader.click()
        row1 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[0].getText())
        row2 = await (await app.client.$('tbody')).$$('tr').then(rows => rows[1].getText())
    
        assert(row1.includes('E2Etest') && row2.includes('E2Etest2'))
    
        dateHeader.click()
        dateHeader.click()
    })
    
})
