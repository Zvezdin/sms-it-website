const assert = require('assert');
const CONFIG = require('../config');


describe('Uploading a chatbot', function () {
    //this.timeout(60000)

    // Tests
    it('Log in to "Manage Chatbots" screen', async function () {
        this.slow(2500)
        const inputAccountSID = await app.client.$('[name="twilioAccountSid"]').then(elem => elem.elementId)
        const inputAuthToken = await app.client.$('[name="twilioAuthToken"]').then(elem => elem.elementId)
        const loginButton = await app.client.$('button')

        app.client.elementSendKeys(inputAccountSID, CONFIG.creds_accountSID)
        app.client.elementSendKeys(inputAuthToken, CONFIG.creds_authToken)
        loginButton.click()

        return (await app.client.waitUntilTextExists('h2', 'Manage Chatbots'))
    })

    it('Go to "Upload New Chatbot" page', async function () {
        const uploadButton = await app.client.$('.new-bot-button=UPLOAD NEW CHATBOT')
        uploadButton.click()

        return (await app.client.waitUntilTextExists('h2', 'Upload New Chatbot'))
    })

    it('Attempt upload without file', async function () {
        await app.client.$('button=UPLOAD').then(btn => btn.click())

        return (app.client.waitUntilTextExists('.notification', 'choose a valid file'))
    })

    it('Attempt upload without name', async function () {
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(inp => inp.setValue('1\uE003'))
        await app.client.$('button=UPLOAD').then(btn => btn.click())

        return (app.client.waitUntilTextExists('.notification', 'enter a chatbot name'))
    })

    it('Attempt upload without unique name', async function () {
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(inp => inp.setValue('1\uE003\uE003\uE003\uE003\uE003\uE003\uE003'))
        await app.client.$('[type="text"]').then(inp => inp.setValue(CONFIG.botNameThatIsNotUnique))
        await app.client.$('button=UPLOAD').then(btn => btn.click())

        return (app.client.waitUntilTextExists('.notification', 'that name already exists'))
    })

    it('Attempt to upload unsupported format', async function() {
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.unsupported_filePath))
        await app.client.$('button=UPLOAD').then(btn => btn.click())
        errorIsDisplayed = (await app.client.$('p=Unexpected Error')).isDisplayed()
        await app.client.$('button=DISMISS').then(btn => btn.click())

        return errorIsDisplayed
    })

    it('Attempt to enter name with invalid characters', async function () {
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(inp => inp.addValue('+'))

        return (app.client.waitUntilTextExists('.notification', 'Invalid input!'))
    })

    it('Attempt to enter name with too many characters', async function () {
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(inp => inp.setValue('0'.repeat(100)))

        return ((await app.client.$$('.notification=Too long!')).length > 0)
    })

    it('Upload file successfully', async function () {
        this.slow(30000)
        this.timeout(60000)

        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(
            inp => inp.setValue('1\uE003\uE003\uE003\uE003\uE003\uE003\uE003' + CONFIG.E2E_botName))
        await app.client.pause(500)
        await app.client.$('button=UPLOAD').then(btn => btn.click())

        const managePage = await app.client.$('h2=Manage Chatbots')
        return managePage.waitForDisplayed({ timeout: 60000 })
    })

    it('Upload second chatbot', async function () {
        this.slow(30000)
        this.timeout(60000)

        await app.client.$('.new-bot-button=UPLOAD NEW CHATBOT').then(btn => btn.click())
        await app.client.$('[type="file"]').then(fileInp => fileInp.setValue(CONFIG.vf_filePath))
        await app.client.$('[type="text"]').then(
            inp => inp.setValue('1\uE003\uE003\uE003\uE003\uE003\uE003\uE003' + CONFIG.E2E_botName + '2'))
        await app.client.pause(500)
        await app.client.$('button=UPLOAD').then(btn => btn.click())
        
        const managePage = await app.client.$('h2=Manage Chatbots')
        return managePage.waitForDisplayed({ timeout: 60000 })
    })
    
})
