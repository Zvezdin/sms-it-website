const assert = require('assert');
const CONFIG = require('../config');


describe('Unlinking a deployed chatbot', function () {
    this.timeout(20000)

    // Tests
    it('Confirmation prompt for unlinking bot', async function () {
        this.slow(3000)
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        await E2EBotRow.$('[id="unlink"]').then(btn => btn.click())

        return (await app.client.$('div=UNLINKING BOT'))
    })

    it('Clicking "Cancel" closes prompt and does nothing', async function () {
        this.slow(750)
        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        await app.client.pause(500)
        await app.client.$('button=CANCEL').then(btn => btn.click())

        return (await E2EBotRow.isDisplayed())
    })

    it('Clicking "Yes" unlinks bot', async function () {
        this.slow(8000)
        this.timeout(16000)

        const E2EBotRow = await (await app.client.$('td=' + CONFIG.E2E_botName)).$('..')
        const deleteButton = await E2EBotRow.$('[id="unlink"]')
        deleteButton.click()
        await app.client.pause(500)
        await app.client.$('button=YES').then(btn => btn.click())

        const unlinkedNotif = await app.client.$('.notification=' + CONFIG.E2E_botName + ' was unlinked from this number')
        return unlinkedNotif.waitForDisplayed({ timeout: 16000 })
    })
    
})
