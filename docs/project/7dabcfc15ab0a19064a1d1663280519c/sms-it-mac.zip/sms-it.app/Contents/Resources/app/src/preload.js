/**
 * Is executed on the UI thread before any other code.
 * It has access to node packages and uses that to inject needed packages for use by UI code on window.*
 * 
 * Configures global unhandled exception handling with logging and user prompts. 
 */

const log = require('electron-log');
const { remote } = require('electron')
const ubfToTwilio = require('ubf-to-twilio')


log.catchErrors({
	showDialog: true,
	onError(error) {
		log.error("Unhandled Error")
		log.error(error)

		//The following doesn't do anything and I'm not sure why. 
		console.log("Submitting prompt")
		const res = remote.dialog.showMessageBoxSync({
			title: 'We\'re Sorry!',
			message: 'A critical error occurred that we did not expect',
			detail: `But no worries! We\'ve collected some diagnostic information in a file and will appreciate 
			it if you can send it to us at team@sms-it.io\n
			You can find the file below:
			
			on Windows: Your User Folder\\AppData\\Roaming\\sms-it\\logs\\renderer.log
			on macOS: ~/Library/Logs/sms-it/renderer.log
			on Linux: ~/.config/{app name}/logs/renderer.log`,
			type: 'error',
			buttons: ['Ok, I\'ll email you'],
		  })

		  console.log("Got result", res) //This line of code is not executed??
	}
})

window.log = log.functions;
window.ubfToTwilio = ubfToTwilio
